package com.example.provisionordering;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class CartAdapter extends ArrayAdapter<CartItem> {
    int p;
    ArrayList<CartItem> ci;
    ListView l;


    public CartAdapter(Activity context, ArrayList<CartItem> list,ListView l)
    {
        super(context,0,list);
        ci=list;
        this.l=l;
    }


    @Override
    public View getView(final int position, View convertView, final ViewGroup parent)
    {

        //System.out.println(position);
        //View listItemView = convertView;
        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.cart_item, parent, false);
        }

        // Get the {@link AndroidFlavor} object located at this position in the list
        final CartItem item = getItem(position);
        //final ListView l = (ListView) convertView.findViewById(R.id.cart);
        // Find the TextView in the list_item_groceries.xmlceries.xml layout with the ID version_name
        TextView name = (TextView) convertView.findViewById(R.id.name);
        // Get the version name from the current AndroidFlavor object and
        // set this text on the name TextView
        name.setText(item.getname());

        TextView qty = (TextView) convertView.findViewById(R.id.quantity);
        qty.setText(item.getquantity());
        // Find the TextView in the list_item_groceries_groceries.xml layout with the ID version_number
        //Spinner s = (Spinner) listItemView.findViewById(R.id.spinner);
        // Get the version number from the current AndroidFlavor object and
        // set this text on the number TextView


            /*Button r = convertView.findViewById(R.id.remove);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println(position);
                    //l.removeView(view);
                    ci.remove(item);
                    notifyDataSetChanged();
                }
            });*/

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        return convertView;
    }

}

