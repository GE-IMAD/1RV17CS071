package com.example.provisionordering;

public class CartItem {
    String name;
    double q;
    public CartItem(String name,double q)
    {
        this.name=name;
        this.q=q;
    }
    public String getname()
    {
        return name;
    }
    public String getquantity()
    {
        double q1; String u;
        if(q>=1000)
        {
            q1=q/1000;
            u=" kg";
        }
        else if(q>=50)
        {
            q1 = q;
            u = " gm";

        }
        else {
            q1=q;
            u=" No";
        }
        String p= Double.toString(q1);
        String r= p+u;
        return r;
    }

    public double get_quan()
    {
        return q;
    }
}
