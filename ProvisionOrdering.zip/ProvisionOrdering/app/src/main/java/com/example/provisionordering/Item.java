package com.example.provisionordering;

import android.widget.Spinner;

public class Item {
    String name;
    Spinner s;
    public Item(String name)
    {
        this.name=name;
    }
    public String getname()
    {
        return name;
    }

}
