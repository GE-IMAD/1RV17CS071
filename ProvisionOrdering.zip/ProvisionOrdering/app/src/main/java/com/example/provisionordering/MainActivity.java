package com.example.provisionordering;

import android.content.Intent;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.os.Environment;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    static ArrayList<CartItem> ci=new ArrayList<>();
    //((MyApplication) this.getApplication()).setCI(ci);
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        getApplicationContext();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((MyApplication) this.getApplication()).setCI(ci);


        Button g= (Button)findViewById(R.id.groceries);
        g.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent i = new Intent(MainActivity.this, Groceries.class);
                //i.putExtra("CART", ci);
                startActivity(i);
            }
        });

        Button t= (Button)findViewById(R.id.toileteries);
        t.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent i = new Intent(MainActivity.this, Toileteries.class);
                //i.putExtra("CART", ci);
                startActivity(i);
            }
        });
        Button c= (Button)findViewById(R.id.cart);
        c.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent i = new Intent(MainActivity.this, Cart.class);
                //i.putExtra("CART", ci);
                startActivity(i);
            }
        });


        Button p= (Button)findViewById(R.id.create);
        p.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                createPdf("THIS IS A TEST STRING TO CHECK CREATION OF PDF!");
            }
        });

        Button m= (Button)findViewById(R.id.maps);
        m.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                Intent i = new Intent(MainActivity.this, MapsActivity.class);
                //i.putExtra("CART", ci);
                startActivity(i);
            }
        });


    }

    public void onBackPressed()
    {
        super.onBackPressed();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createPdf(String sometext){
        String pdf="";
        int x1=10,y=20,x2=150;

        PdfDocument document = new PdfDocument();
        // crate a page description
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        // start a page
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);

        ArrayList<CartItem> ci= ((MyApplication) this.getApplication()).getCI();
        int i;
        for (i=0;i<ci.size();i++)
        {
            CartItem k= ci.get(i);
            String n=k.getname();
            String q=k.getquantity();
            pdf=n;
            canvas.drawText(pdf, x1, y, paint);
            pdf=q;
            canvas.drawText(pdf, x2, y, paint);
            y=y+20;
        }



        // create a new document

        //paint.setColor(Color.RED);

        //canvas.drawCircle(50, 50, 30, paint);

        //System.out.println(pdf);

        //canvas.drawt
        // finish the page
        document.finishPage(page);
// draw text on the graphics object of the page
        // Create Page 2
        /*pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 2).create();
        page = document.startPage(pageInfo);
        canvas = page.getCanvas();
        paint = new Paint();
        paint.setColor(Color.BLUE);
        canvas.drawCircle(100, 100, 100, paint);
        document.finishPage(page);*/
        // write the document content
        String directory_path = Environment.getExternalStorageDirectory().getPath() + "/Pdf test/";
        File file = new File(directory_path);
        if (!file.exists()) {
            file.mkdirs();
        }
        String targetPdf = directory_path+"List.pdf";
        File filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));
            Toast.makeText(this, "Done", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e("main", "error "+e.toString());
            Toast.makeText(this, "Something wrong: " + e.toString(),  Toast.LENGTH_LONG).show();
        }
        // close the document
        document.close();
    }
}


