package com.example.provisionordering;

import android.app.Application;
import com.example.provisionordering.MyApplication;

import java.util.ArrayList;

public class MyApplication extends Application {

    private ArrayList<CartItem> ci;

    public ArrayList<CartItem> getCI() {
        return ci;
    }

    public void setCI(ArrayList<CartItem> ci) {
        this.ci = ci;
    }
}
