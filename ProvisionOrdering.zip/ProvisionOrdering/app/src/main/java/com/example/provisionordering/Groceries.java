package com.example.provisionordering;

import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Groceries extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groceries);
        getSupportActionBar().setTitle("Groceries");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        ListView l=(ListView)findViewById(R.id.list);
        ArrayList<Item> items=new ArrayList<Item>();
        items.add(new Item("Toor Dal"));
        items.add(new Item("Moong Dal"));
        items.add(new Item("Rice"));
        items.add(new Item("Udad Dal"));
        items.add(new Item("Wheat Flour"));

        ItemAdapterGroceries i=new ItemAdapterGroceries(this,items);
        l.setAdapter(i);


    }
    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }
    public void addtocart(View v)
    {
        ArrayList<CartItem> ci= ((MyApplication) this.getApplication()).getCI();
        //(ArrayList<CartItem>) getIntent().getSerializableExtra("CART");
        int q1;
        double q;
        double quan=0.0;
        int pos=0,flag=0;
        CharSequence text;
        CartItem c;
        LinearLayout l=(LinearLayout)v.getParent();
        TextView t=(TextView)l.getChildAt(0);
        String n=(String)t.getText();

        Spinner s=(Spinner)l.getChildAt(1);
        String p= s.getSelectedItem().toString();

        int le=p.length();
        String unit=p.substring(le-2,le);
        System.out.println(unit);

        if(unit.equals("kg"))
        {
            if (p.charAt(2) == ' ')
            {
                String p1 = p.substring(0, 2);
                q1 = Integer.parseInt(p1);
            }
            else
            {
                String p1 = p.substring(0,1);
                q1 = Integer.parseInt(p1);
            }
            q=q1*1000;
        }
        else
        {
            if (p.charAt(2) == ' ')
            {
                String p1 = p.substring(0, 2);
                q1 = Integer.parseInt(p1);
            }
            else
            {
                String p1 = p.substring(0, 3);
                q1 = Integer.parseInt(p1);
            }
            q=q1;
        }
        //CartItem c=new CartItem(n,q);
        int i;
        for(i=0;i<ci.size();i++)
        {
            CartItem k=ci.get(i);
            String name=k.getname();
            if(name.equals(n))
            {
                flag=1;
                pos=i;
                quan=k.get_quan();
                break;
            }
        }
        if(flag==1)
        {
            ci.remove(pos);
            q=q+quan;
            c=new CartItem(n,q);
            String b= c.getquantity();
            text="Item "+n+" already present in cart!"+"\nQuantity increased to: "+b;
        }
        else{
            c=new CartItem(n,q);
            String b= c.getquantity();
            text = "Item:"+n+"\nQuantity:"+b+"\nAdded to Cart";
        }
        ci.add(c);
        System.out.println("The Quantity selected in grams is :"+q);

        Context context = getApplicationContext();

        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        s.setSelection(0);

    }


}
