package com.example.provisionordering;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    int pos;
    CartAdapter k;
    ListView l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ArrayList<CartItem> ci= ((MyApplication) this.getApplication()).getCI();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        getSupportActionBar().setTitle("Cart");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        l=(ListView)findViewById(R.id.cart);

        k=new CartAdapter(this,ci,l);
        l.setAdapter(k);
    }
    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }


}

